"""Unit-тесты для arbitrage_engine (cross-pair logic, format helpers).

Все тесты детерминированные, без сетевых вызовов.
Запуск: pytest zenith-bot/tests/test_arb_engine.py -v
"""
from __future__ import annotations

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

os.environ.setdefault("BYBIT_API_KEY", "test")
os.environ.setdefault("BYBIT_API_SECRET", "test")
os.environ.setdefault("OKX_API_KEY", "test")
os.environ.setdefault("OKX_API_SECRET", "test")
os.environ.setdefault("OKX_PASSPHRASE", "test")
os.environ.setdefault("TELEGRAM_TOKEN", "000:test")
os.environ.setdefault("TELEGRAM_CHAT_ID", "12345")
os.environ.setdefault("GROQ_API_KEY", "test")
os.environ.setdefault("NEWS_API_KEY", "test")

import arbitrage_engine


def _make_snap(
    exchange: str,
    symbol: str,
    funding_rate: float,
    mark_price: float = 50000.0,
    interval_hours: float = 8.0,
) -> arbitrage_engine.FundingSnapshot:
    """Создать FundingSnapshot с базовыми полями для тестов."""
    apr = funding_rate * (8760.0 / interval_hours)
    fee_drag = 0.0012
    net_apr = apr - fee_drag
    side = "SHORT_PERP" if funding_rate > 0 else "LONG_PERP"
    return arbitrage_engine.FundingSnapshot(
        exchange=exchange,
        symbol=symbol,
        funding_rate=funding_rate,
        next_funding_ts=0,
        mark_price=mark_price,
        interval_hours=interval_hours,
        apr=apr,
        net_apr=net_apr,
        side_recommendation=side,
    )


class TestFundingSnapshot:
    def test_snapshot_has_required_fields(self):
        s = _make_snap("bybit", "BTCUSDT", 0.001)
        assert s.exchange == "bybit"
        assert s.symbol == "BTCUSDT"
        assert s.funding_rate == 0.001
        assert s.apr > 0
        assert s.net_apr is not None

    def test_negative_rate_gives_long_recommendation(self):
        s = _make_snap("okx", "ETHUSDT", -0.001)
        assert s.side_recommendation == "LONG_PERP"

    def test_positive_rate_gives_short_recommendation(self):
        s = _make_snap("bybit", "BTCUSDT", 0.002)
        assert s.side_recommendation == "SHORT_PERP"


class TestTopByApr:
    def _make_snapshots_dict(self):
        return {
            "bybit": [
                _make_snap("bybit", "BTCUSDT", 0.003),
                _make_snap("bybit", "ETHUSDT", 0.001),
                _make_snap("bybit", "SOLUSDT", -0.002),
            ],
            "okx": [
                _make_snap("okx", "BTCUSDT", -0.001),
                _make_snap("okx", "ETHUSDT", 0.004),
            ],
        }

    def test_returns_sorted_by_abs_apr(self):
        snaps = self._make_snapshots_dict()
        result = arbitrage_engine.top_by_apr(snaps, limit=10, min_abs_apr=0.0)
        aprs = [abs(r.apr) for r in result]
        assert aprs == sorted(aprs, reverse=True), "Должны быть отсортированы по убыванию |APR|"

    def test_min_abs_apr_filter(self):
        snaps = self._make_snapshots_dict()
        high_threshold = 100.0
        result = arbitrage_engine.top_by_apr(snaps, limit=10, min_abs_apr=high_threshold)
        assert len(result) == 0, "Порог 100 APR должен отфильтровать всё"

    def test_limit_respected(self):
        snaps = self._make_snapshots_dict()
        result = arbitrage_engine.top_by_apr(snaps, limit=2, min_abs_apr=0.0)
        assert len(result) <= 2

    def test_empty_snapshots(self):
        result = arbitrage_engine.top_by_apr({}, limit=10, min_abs_apr=0.0)
        assert result == []


class TestCrossExchangePairs:
    def _snaps_with_edge(self):
        return {
            "bybit": [
                _make_snap("bybit", "BTCUSDT", 0.005, 50000.0),
            ],
            "okx": [
                _make_snap("okx", "BTCUSDT", -0.001, 50000.0),
            ],
        }

    def test_finds_cross_pair(self):
        snaps = self._snaps_with_edge()
        pairs = arbitrage_engine.cross_exchange_pairs(snaps, min_edge_apr=0.0)
        assert len(pairs) > 0, "Должна быть найдена хотя бы одна пара"

    def test_pair_has_correct_structure(self):
        snaps = self._snaps_with_edge()
        pairs = arbitrage_engine.cross_exchange_pairs(snaps, min_edge_apr=0.0)
        if pairs:
            p = pairs[0]
            assert hasattr(p, "symbol")
            assert hasattr(p, "long_leg")
            assert hasattr(p, "short_leg")
            assert hasattr(p, "net_edge_apr")

    def test_long_leg_is_lower_rate(self):
        snaps = self._snaps_with_edge()
        pairs = arbitrage_engine.cross_exchange_pairs(snaps, min_edge_apr=0.0)
        if pairs:
            p = pairs[0]
            assert p.long_leg.funding_rate <= p.short_leg.funding_rate, \
                "LONG должен быть на бирже с меньшим rate"

    def test_high_threshold_filters_all(self):
        snaps = self._snaps_with_edge()
        pairs = arbitrage_engine.cross_exchange_pairs(snaps, min_edge_apr=999.0)
        assert len(pairs) == 0

    def test_same_symbol_different_exchanges(self):
        snaps = {
            "bybit": [_make_snap("bybit", "BTCUSDT", 0.003)],
            "okx": [_make_snap("okx", "BTCUSDT", -0.002)],
        }
        pairs = arbitrage_engine.cross_exchange_pairs(snaps, min_edge_apr=0.0)
        for p in pairs:
            long_ex = p.long_leg.exchange.lower()
            short_ex = p.short_leg.exchange.lower()
            assert long_ex != short_ex, "Нельзя арбитражить между одинаковыми биржами"

    def test_no_pairs_for_same_exchange(self):
        snaps = {
            "bybit": [
                _make_snap("bybit", "BTCUSDT", 0.003),
                _make_snap("bybit", "ETHUSDT", -0.001),
            ],
        }
        pairs = arbitrage_engine.cross_exchange_pairs(snaps, min_edge_apr=0.0)
        for p in pairs:
            assert p.long_leg.exchange != p.short_leg.exchange


class TestFormatHelpers:
    def test_format_apr_positive(self):
        result = arbitrage_engine.format_apr(0.20)
        assert "20" in result or "%" in result

    def test_format_apr_negative(self):
        result = arbitrage_engine.format_apr(-0.10)
        assert "-" in result or "−" in result or "%" in result

    def test_format_pct(self):
        result = arbitrage_engine.format_pct(0.001)
        assert "%" in result or "0.1" in result
