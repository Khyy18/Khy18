"""Unit-тесты для индикаторов и стратегии v2.

Полностью детерминированные, без сети и биржи.
Запуск: pytest zenith-bot/tests/test_strategy.py -v
"""
from __future__ import annotations

import math
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

os.environ.setdefault("BYBIT_API_KEY", "test")
os.environ.setdefault("BYBIT_API_SECRET", "test")
os.environ.setdefault("OKX_API_KEY", "test")
os.environ.setdefault("OKX_API_SECRET", "test")
os.environ.setdefault("OKX_PASSPHRASE", "test")
os.environ.setdefault("TELEGRAM_TOKEN", "000:test")
os.environ.setdefault("TELEGRAM_CHAT_ID", "12345")
os.environ.setdefault("GROQ_API_KEY", "test")
os.environ.setdefault("NEWS_API_KEY", "test")

import strategy_v2


def _make_trending_ohlc(n: int = 200) -> tuple[list, list, list]:
    """Восходящий тренд: закрытие + 1 каждую свечу, тени ±0.5."""
    closes = [100.0 + i for i in range(n)]
    highs = [c + 0.5 for c in closes]
    lows = [c - 0.5 for c in closes]
    return highs, lows, closes


def _make_flat_ohlc(n: int = 100) -> tuple[list, list, list]:
    """Флет: цена колеблется ±0.5 вокруг 100."""
    import math
    closes = [100.0 + 0.5 * math.sin(i * 0.3) for i in range(n)]
    highs = [c + 0.3 for c in closes]
    lows = [c - 0.3 for c in closes]
    return highs, lows, closes


class TestATR:
    def test_returns_correct_length(self):
        highs, lows, closes = _make_trending_ohlc(50)
        result = strategy_v2.atr(highs, lows, closes, 14)
        assert len(result) == 50

    def test_first_period_values_are_none(self):
        highs, lows, closes = _make_trending_ohlc(50)
        result = strategy_v2.atr(highs, lows, closes, 14)
        for v in result[:14]:
            assert v is None, f"Expected None at early index, got {v}"

    def test_values_are_positive_for_trending(self):
        highs, lows, closes = _make_trending_ohlc(100)
        result = strategy_v2.atr(highs, lows, closes, 14)
        non_none = [v for v in result if v is not None]
        assert all(v > 0 for v in non_none), "ATR должен быть > 0"

    def test_returns_all_none_for_insufficient_data(self):
        result = strategy_v2.atr([1.0, 2.0], [0.5, 1.5], [1.0, 2.0], 14)
        assert all(v is None for v in result)

    def test_atr_stable_flat_market(self):
        highs, lows, closes = _make_flat_ohlc(100)
        result = strategy_v2.atr(highs, lows, closes, 14)
        non_none = [v for v in result if v is not None]
        assert len(non_none) > 0
        assert all(0 < v < 2.0 for v in non_none), f"Флет ATR должен быть мал: {non_none[-1]}"

    def test_atr_wilder_smoothing(self):
        n = 50
        highs = [10.0] * n
        lows = [0.0] * n
        closes = [5.0] * n
        result = strategy_v2.atr(highs, lows, closes, 14)
        non_none = [v for v in result if v is not None]
        assert all(abs(v - 10.0) < 0.001 for v in non_none), \
            "При постоянном TR=10 ATR должен сойтись к 10.0"


class TestADX:
    def test_returns_correct_length(self):
        highs, lows, closes = _make_trending_ohlc(100)
        result = strategy_v2.adx(highs, lows, closes, 14)
        assert len(result) == 100

    def test_strong_trend_adx_above_25(self):
        n = 200
        closes = [float(i * 2) for i in range(n)]
        highs = [c + 1.0 for c in closes]
        lows = [c - 0.1 for c in closes]
        result = strategy_v2.adx(highs, lows, closes, 14)
        non_none = [v for v in result if v is not None]
        assert len(non_none) > 0
        assert non_none[-1] > 25.0, f"Сильный тренд должен давать ADX>25, получили {non_none[-1]:.1f}"

    def test_flat_adx_below_25(self):
        highs, lows, closes = _make_flat_ohlc(200)
        result = strategy_v2.adx(highs, lows, closes, 14)
        non_none = [v for v in result if v is not None]
        if non_none:
            assert non_none[-1] < 30.0, f"Флет ADX должен быть мал: {non_none[-1]:.1f}"

    def test_adx_in_0_100_range(self):
        highs, lows, closes = _make_trending_ohlc(200)
        result = strategy_v2.adx(highs, lows, closes, 14)
        non_none = [v for v in result if v is not None]
        assert all(0 <= v <= 100 for v in non_none), "ADX должен быть в [0,100]"


class TestShouldTimeStop:
    def test_no_stop_before_hours(self):
        from datetime import datetime, timezone, timedelta
        t0 = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc).isoformat()
        t1 = datetime(2024, 1, 1, 10, 0, 0, tzinfo=timezone.utc).isoformat()
        result = strategy_v2.should_time_stop(t0, t1, "long", 100.0, 99.0, hours=48.0)
        assert not result

    def test_stop_after_hours_at_loss(self):
        from datetime import datetime, timezone, timedelta
        t0 = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc).isoformat()
        t1 = datetime(2024, 1, 3, 1, 0, 0, tzinfo=timezone.utc).isoformat()
        result = strategy_v2.should_time_stop(t0, t1, "long", 100.0, 99.0, hours=48.0)
        assert result

    def test_no_stop_after_hours_with_profit(self):
        from datetime import datetime, timezone, timedelta
        t0 = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc).isoformat()
        t1 = datetime(2024, 1, 3, 1, 0, 0, tzinfo=timezone.utc).isoformat()
        result = strategy_v2.should_time_stop(t0, t1, "long", 100.0, 110.0, hours=48.0)
        assert not result

    def test_naive_vs_aware_does_not_raise(self):
        t0 = "2024-01-01T00:00:00"
        t1 = "2024-01-03T01:00:00+00:00"
        try:
            result = strategy_v2.should_time_stop(t0, t1, "long", 100.0, 99.0, hours=48.0)
        except TypeError:
            assert False, "should_time_stop не должен бросать TypeError при naive/aware"

    def test_aware_vs_naive_does_not_raise(self):
        t0 = "2024-01-01T00:00:00+00:00"
        t1 = "2024-01-03T01:00:00"
        try:
            result = strategy_v2.should_time_stop(t0, t1, "long", 100.0, 99.0, hours=48.0)
        except TypeError:
            assert False, "should_time_stop не должен бросать TypeError при aware/naive"

    def test_short_stop_at_loss(self):
        from datetime import datetime, timezone
        t0 = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc).isoformat()
        t1 = datetime(2024, 1, 3, 1, 0, 0, tzinfo=timezone.utc).isoformat()
        result = strategy_v2.should_time_stop(t0, t1, "short", 100.0, 101.0, hours=48.0)
        assert result

    def test_invalid_iso_returns_false(self):
        result = strategy_v2.should_time_stop("not-a-date", "also-not", "long", 100.0, 99.0)
        assert not result


class TestComputeHardStop:
    def test_long_stop_below_entry(self):
        stop = strategy_v2.compute_hard_stop(100.0, 2.0, "long")
        assert stop < 100.0

    def test_short_stop_above_entry(self):
        stop = strategy_v2.compute_hard_stop(100.0, 2.0, "short")
        assert stop > 100.0

    def test_zero_atr_returns_entry(self):
        stop = strategy_v2.compute_hard_stop(100.0, 0.0, "long")
        assert stop == 100.0


class TestComputeChandelier:
    def test_not_activated_before_atr_move(self):
        result = strategy_v2.compute_chandelier(
            high_since_entry=101.0,
            low_since_entry=100.0,
            atr_now=2.0,
            side="long",
            entry=100.0,
            activation_atr=2.0,
        )
        assert result is None

    def test_activated_after_atr_move(self):
        result = strategy_v2.compute_chandelier(
            high_since_entry=103.0,
            low_since_entry=100.0,
            atr_now=1.0,
            side="long",
            entry=100.0,
            activation_atr=2.0,
            trail_mult=2.0,
        )
        assert result is not None
        assert result == 103.0 - 2.0 * 1.0

    def test_short_chandelier(self):
        result = strategy_v2.compute_chandelier(
            high_since_entry=100.0,
            low_since_entry=96.0,
            atr_now=1.0,
            side="short",
            entry=100.0,
            activation_atr=2.0,
            trail_mult=2.0,
        )
        assert result is not None
        assert abs(result - (96.0 + 2.0)) < 1e-9
